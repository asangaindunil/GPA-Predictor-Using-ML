# Student Helper GPA Advisor Micro Services Made with Python Flask
 
Student Create Postman Sample API Request and response Request

**Request**

{<br/>
    "name":"asanga",<br/>
    "indexno":"it17069878",<br/>
    "nic":"971630841V",<br/>
    "email":"asanga600gmail.com",<br/>
    "semester":"2nd year 2nd semester"<br/>
}<br/><br/>

**SUCESS RESPONSE**<br/>

{ "status": "Success" }<br/>

**BAD RESPONSE**

{<br/>
    "errors": {<br/>
        "email": "Email must be a string"<br/>
    },<br/>
    "status": "Error"<br/>
}<br/>
